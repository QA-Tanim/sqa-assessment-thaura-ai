/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.59025997803002, "KoPercent": 1.4097400219699743};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.06861039912120102, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.11102831594634874, 500, 1500, "Imprint Page"], "isController": false}, {"data": [0.07766272189349112, 500, 1500, "Contact Page"], "isController": false}, {"data": [0.03160112359550562, 500, 1500, "Story Page"], "isController": false}, {"data": [0.09538002980625931, 500, 1500, "Careers Page"], "isController": false}, {"data": [0.06783369803063458, 500, 1500, "Constitution Page"], "isController": false}, {"data": [0.09165424739195231, 500, 1500, "Community Page"], "isController": false}, {"data": [0.07600596125186289, 500, 1500, "Data-processing-addendum Page"], "isController": false}, {"data": [0.06524926686217009, 500, 1500, "Pricing Page"], "isController": false}, {"data": [0.05235988200589971, 500, 1500, "Faq Page"], "isController": false}, {"data": [0.06376811594202898, 500, 1500, "Download Page"], "isController": false}, {"data": [0.0, 500, 1500, "Home Page"], "isController": false}, {"data": [0.0712166172106825, 500, 1500, "Terms-of-service Page"], "isController": false}, {"data": [0.08444444444444445, 500, 1500, "Privacy-Policy Page"], "isController": false}, {"data": [0.07441348973607038, 500, 1500, "Api-platform Page"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 10924, 154, 1.4097400219699743, 19067.026089344505, 201, 645883, 7555.0, 29216.0, 66339.0, 292725.0, 16.75709423027659, 1277.101764648556, 1.967958375325777], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Imprint Page", 671, 0, 0.0, 4781.605067064081, 201, 80471, 4094.0, 8322.600000000002, 11025.199999999999, 22576.959999999865, 1.3058615864564056, 71.94353652337706, 0.1517553992073362], "isController": false}, {"data": ["Contact Page", 676, 0, 0.0, 9623.483727810652, 202, 262321, 6117.5, 13995.500000000007, 21751.099999999988, 95030.08000000112, 1.1460229950531138, 68.75466472470019, 0.1331804066516802], "isController": false}, {"data": ["Story Page", 712, 0, 0.0, 17743.55196629214, 999, 314888, 8755.5, 29531.20000000001, 64313.50000000016, 229555.74000000005, 1.1218357771076175, 73.54707150836492, 0.12817850187655394], "isController": false}, {"data": ["Careers Page", 671, 0, 0.0, 6852.748137108786, 202, 116917, 5190.0, 10925.0, 17582.0, 52810.59999999942, 1.244401583783834, 77.07998403929787, 0.14461307467800413], "isController": false}, {"data": ["Constitution Page", 1371, 0, 0.0, 16400.535375638236, 205, 368336, 9167.0, 25448.399999999994, 48077.799999999836, 226366.95999999996, 2.1765912453721636, 198.4247747526727, 0.26357159611928543], "isController": false}, {"data": ["Community Page", 671, 0, 0.0, 7136.308494783901, 202, 170055, 5263.0, 11643.000000000002, 17610.999999999996, 47192.359999999775, 1.190305133213061, 73.0480031068117, 0.14065129015505898], "isController": false}, {"data": ["Data-processing-addendum Page", 671, 0, 0.0, 9962.26229508196, 204, 229709, 7612.0, 16356.80000000001, 23322.599999999995, 85319.67999999989, 1.2144268846240165, 107.43408459406288, 0.16129107061412717], "isController": false}, {"data": ["Pricing Page", 682, 0, 0.0, 11017.34017595308, 203, 223673, 7406.0, 16089.400000000016, 26958.550000000025, 134774.25999999966, 1.129526178673817, 75.97938741526484, 0.1312632961544768], "isController": false}, {"data": ["Faq Page", 678, 1, 0.14749262536873156, 21777.013274336274, 208, 295512, 13924.0, 36434.1, 70428.29999999984, 210220.4300000001, 1.131990416482315, 138.57908162999107, 0.12694032580203524], "isController": false}, {"data": ["Download Page", 690, 0, 0.0, 11132.637681159424, 203, 158256, 7443.5, 20470.099999999995, 30624.399999999998, 88021.4400000003, 1.1283746988956647, 74.83967228993833, 0.1322314100268357], "isController": false}, {"data": ["Home Page", 718, 153, 21.309192200557103, 123594.76601671317, 11480, 645883, 56444.5, 331741.5, 409055.3499999996, 486415.08999999985, 1.1090567302597942, 92.87961993133656, 0.09886345820261755], "isController": false}, {"data": ["Terms-of-service Page", 674, 0, 0.0, 11650.029673590512, 204, 361632, 8523.0, 19557.0, 29337.75, 82959.5, 1.1725572882959994, 104.68852547115405, 0.14656966103699992], "isController": false}, {"data": ["Privacy-Policy Page", 675, 0, 0.0, 7805.927407407404, 202, 159965, 5331.0, 11635.199999999997, 20435.399999999998, 80462.60000000003, 1.1608828901340433, 66.7825090742346, 0.14284301187196236], "isController": false}, {"data": ["Api-platform Page", 1364, 0, 0.0, 11409.134164222862, 203, 377931, 7644.5, 17766.0, 26269.0, 114784.84999999969, 2.2054745570052114, 173.78665676776708, 0.2670691846373498], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 124,565; received: 97,327)", 1, 0.6493506493506493, 0.009154155986818015], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 80,943)", 6, 3.896103896103896, 0.054924935920908094], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 97,327)", 147, 95.45454545454545, 1.3456609300622482], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 10924, 154, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 97,327)", 147, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 80,943)", 6, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 124,565; received: 97,327)", 1, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Faq Page", 678, 1, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 124,565; received: 97,327)", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Home Page", 718, 153, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 97,327)", 147, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 107,638; received: 80,943)", 6, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
